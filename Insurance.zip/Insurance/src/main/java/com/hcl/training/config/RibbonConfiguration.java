/*
 * package com.hcl.training.config;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration;
 * 
 * import com.netflix.client.config.IClientConfig; import
 * com.netflix.loadbalancer.AvailabilityFilteringRule; import
 * com.netflix.loadbalancer.IRule; import com.netflix.loadbalancer.RandomRule;
 * 
 * //@Configuration public class RibbonConfiguration {
 * 
 * @Autowired IClientConfig iClientConfig;
 * 
 * @Bean public IRule randomRule(IClientConfig iClientConfig) { return new
 * RandomRule(); }
 * 
 * @Bean public IRule ribbonRule(IClientConfig iClientConfig) { return new
 * AvailabilityFilteringRule(); }
 * 
 * }
 */