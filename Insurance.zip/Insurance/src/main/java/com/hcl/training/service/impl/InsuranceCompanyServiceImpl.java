package com.hcl.training.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.training.entity.InsuranceCompany;
import com.hcl.training.repository.InsuranceCompanyRepository;
import com.hcl.training.service.InsuranceCompanyService;

@Service
public class InsuranceCompanyServiceImpl implements InsuranceCompanyService {

	@Autowired
	InsuranceCompanyRepository insuranceCompanyRepository;

	@Override
	public List<InsuranceCompany> listInsuranceCompanies() {
		List<InsuranceCompany> companyList = insuranceCompanyRepository.findAll();
		return companyList;
	}

	@Override
	public List<InsuranceCompany> listInsuranceCompaniesByName(String comapanyName) {
		System.out.println("listInsuranceCompaniesByName...");
		List<InsuranceCompany> comapanyNameList = insuranceCompanyRepository.findByCompanyNameContains(comapanyName);
		return comapanyNameList;
	}

}
