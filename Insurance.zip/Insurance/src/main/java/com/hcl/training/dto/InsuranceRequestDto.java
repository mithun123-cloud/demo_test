package com.hcl.training.dto;

public class InsuranceRequestDto {
	
	private Integer insuranceId;
	
	private Double amount;
	
	
	
	
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Integer getInsuranceId() {
		return insuranceId;
	}
	public void setInsuranceId(Integer insuranceId) {
		this.insuranceId = insuranceId;
	}
	
	

}
