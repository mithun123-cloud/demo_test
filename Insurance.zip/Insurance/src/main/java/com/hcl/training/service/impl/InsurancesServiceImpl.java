package com.hcl.training.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.training.dto.InsurancesResponseDto;
import com.hcl.training.entity.Insurances;
import com.hcl.training.repository.InsurancesRepository;
import com.hcl.training.service.InsurancesService;
@Service
public class InsurancesServiceImpl implements InsurancesService{
	
	@Autowired
	InsurancesRepository insurancesRepository;

	@Override
	public List<Insurances> listInsurances() {
		// TODO Auto-generated method stub
		return insurancesRepository.findAll();
	}

	@Override
	public List<InsurancesResponseDto> listInsurancesByName(String insuranceName) {
		
		List<Insurances>  insuranceList = insurancesRepository.findByInsuranceNameContains(insuranceName);
		
		List<InsurancesResponseDto> insurancesDtoList = new ArrayList<>();

		InsurancesResponseDto insurancesDtos = null;
		
		for(Insurances insurance : insuranceList) {
			insurancesDtos = new InsurancesResponseDto();
			
			BeanUtils.copyProperties(insurance, insurancesDtos);
			
			insurancesDtos.setInsuranceCompanyName(insurance.getInsuranceCompany().getCompanyName());
			
			insurancesDtoList.add(insurancesDtos);
		}
		return insurancesDtoList;
	}


	

}
