package com.hcl.training.service;

import java.util.List;

import com.hcl.training.dto.InsurancesResponseDto;
import com.hcl.training.entity.InsuranceCompany;
import com.hcl.training.entity.Insurances;

public interface InsurancesService {

	List<Insurances> listInsurances();

	List<InsurancesResponseDto> listInsurancesByName(String insuranceName);

}
