package com.hcl.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.dto.CustomerInsuranceRequestDto;
import com.hcl.training.dto.CustomerInsuranceResponseDto;
import com.hcl.training.service.CustomerInsuranceService;

@RestController
public class CustomerInsuranceController {
	
	
	@Autowired
	CustomerInsuranceService customerInsuranceService;
	
	@PostMapping("/optingInsurance")
	public ResponseEntity<String> optingInsurance(@RequestBody CustomerInsuranceRequestDto customerInsuranceDto) {
		String message = customerInsuranceService.optingInsurance(customerInsuranceDto);
		return new ResponseEntity<String>(message, HttpStatus.CREATED);
	}
	

	@GetMapping("/search/{customerId}")
	public ResponseEntity<List<CustomerInsuranceResponseDto>> getCustomer(@PathVariable("customerId") Integer customerId, @RequestParam("pageNumber") Integer pageNumber,  @RequestParam("pageSize") Integer pageSize) {
		System.out.println("customerId::"+customerId);
		return new ResponseEntity<List<CustomerInsuranceResponseDto>>(customerInsuranceService.searchCustomerByUserId(customerId, pageNumber, pageSize), HttpStatus.OK);
	}
}
