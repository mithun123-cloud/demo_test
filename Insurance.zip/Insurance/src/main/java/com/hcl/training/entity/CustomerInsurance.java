package com.hcl.training.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Mithun Bhadra
 */
@Entity
@Table(name = "T_CUSTOMER_INSURANCE")
public class CustomerInsurance implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "policy_number")
	private Long policyNumber;

	@Column(name = "customer_id")
	private Integer customerId; 
	
	
	@JsonFormat(pattern = "dd/MM/yyyy hh:mm")
	@Column(name = "created_date")
	private Date date;

	
	@Column(name = "premium_amount")
	private Double premiumAmount;
	
	private String status;
	
		
	@ManyToOne
	private Insurances insurances;

	public Long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(Long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Double getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(Double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Insurances getInsurances() {
		return insurances;
	}

	public void setInsurances(Insurances insurances) {
		this.insurances = insurances;
	}
	
	
	
	

	

	

}
