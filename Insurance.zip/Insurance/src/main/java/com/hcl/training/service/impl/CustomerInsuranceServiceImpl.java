package com.hcl.training.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hcl.training.dto.AccountRequestDto;
import com.hcl.training.dto.CustomerInsuranceRequestDto;
import com.hcl.training.dto.CustomerInsuranceResponseDto;
import com.hcl.training.dto.InsuranceRequestDto;
import com.hcl.training.entity.Customer;
import com.hcl.training.entity.CustomerInsurance;
import com.hcl.training.entity.Insurances;
import com.hcl.training.feignclient.BankServiceProxy;
import com.hcl.training.repository.CustomerInsurancesRepository;
import com.hcl.training.repository.CustomerRepository;
import com.hcl.training.repository.InsurancesRepository;
import com.hcl.training.service.CustomerInsuranceService;

@Service
public class CustomerInsuranceServiceImpl implements CustomerInsuranceService{

	@Autowired
	CustomerInsurancesRepository customerInsurancesRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	InsurancesRepository insurancesRepository;
	
	@Autowired
	BankServiceProxy bankServiceProxy;
	
	@Override
	public String optingInsurance(CustomerInsuranceRequestDto customerInsuranceDto) { 
		
		CustomerInsurance customerinsurance = new CustomerInsurance();
	        Optional<Customer> customer = customerRepository.findById(customerInsuranceDto.getCustomerId());
	        double total = 0;
	        
	        if (!customer.isPresent()) {
				return null;
			}
	        
	        Map<Long, Double> insurancePaymentMap = new HashMap<>();
			Map<Long, Double> insurancePaymentResult = new HashMap<>();
	 
	        for (InsuranceRequestDto insuranceDto : customerInsuranceDto.getInsuranceRequestDto()) {
	            CustomerInsurance customerInsurance = new CustomerInsurance();
	            
	            customerInsurance.setCustomerId(customer.get().getCustomerId());
	            customerInsurance.setDate(Calendar.getInstance().getTime());
	            Optional<Insurances> insurance = insurancesRepository.findById(insuranceDto.getInsuranceId());
	            Insurances insurances = insurance.get();
	            customerInsurance.setInsurances(insurance.get());
	            
	            total = total + insuranceDto.getAmount();
	            
	            insurancePaymentResult = insurancePayment(insurances, insurancePaymentMap, insuranceDto.getAmount());
	            
	            customerInsurance.setPremiumAmount(insuranceDto.getAmount());
	            
	            customerInsurance.setStatus("Success");
	            
	            customerInsurancesRepository.save(customerInsurance);
	        }
	        if (total == 0) {
				return null;
			}
	        customerinsurance.setPremiumAmount(total);
	        
	        String status = "";
			AccountRequestDto accountRequestDto = new AccountRequestDto();
			
			accountRequestDto.setFromAccount(customerInsuranceDto.getFromAccount());
			
			accountRequestDto.setRemarks("breakfast");
			
			for (Map.Entry<Long, Double> venderSet : insurancePaymentResult.entrySet()) {

				accountRequestDto.setToAccount(venderSet.getKey());
				
				accountRequestDto.setAmount(venderSet.getValue());
				System.out.println("");
				status = bankServiceProxy.fundTransafer(accountRequestDto);
				System.out.println("status:::"+status);
			}
	        return "Success Optaining the insurance";
	    }

	
	private Map<Long, Double> insurancePayment(Insurances insurances, Map<Long, Double> insurancePaymentMap,
			double amount) {
		if (insurancePaymentMap.size() > 0) {
			Iterator<Long> iterator = insurancePaymentMap.keySet().iterator();

			while (iterator.hasNext()) {
				Long key = iterator.next();
				Double value = insurancePaymentMap.get(key);
				System.out.println("CompanyAccountNumber::--->"+insurances.getInsuranceCompany().getCompanyAccountNumber());
				if (key.equals(insurances.getInsuranceCompany().getCompanyAccountNumber())) {
					insurancePaymentMap.replace(key, value + Double.valueOf(amount));
				} else {
					insurancePaymentMap.put(insurances.getInsuranceCompany().getCompanyAccountNumber(),
							Double.valueOf(amount));
				}
			}
		}
		else {
			insurancePaymentMap.put(insurances.getInsuranceCompany().getCompanyAccountNumber(),
					Double.valueOf(amount));
		}
		return insurancePaymentMap;
	}
	

	
	
	
	
	
	
	
	
	
	
	
	@Override
	public List<CustomerInsuranceResponseDto> searchCustomerByUserId(Integer customerId,Integer pageNumber, Integer pageSize) {
		System.out.println("serchUserOrderByUserId in service..."+customerId);
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		List<CustomerInsurance> uo = customerInsurancesRepository.findByCustomerId(customerId,pageable);
		List<CustomerInsuranceResponseDto> customerInsuranceResponseDtoList = new ArrayList<>();
		CustomerInsuranceResponseDto customerInsuranceResponseDto = null;
		for(CustomerInsurance customerInsurance : uo) {
			System.out.println("uo:::"+uo);
			customerInsuranceResponseDto = new CustomerInsuranceResponseDto();
			BeanUtils.copyProperties(customerInsurance, customerInsuranceResponseDto);
			customerInsuranceResponseDtoList.add(customerInsuranceResponseDto);
		}
		return customerInsuranceResponseDtoList;
	}
}
