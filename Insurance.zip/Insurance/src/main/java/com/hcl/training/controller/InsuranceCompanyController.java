package com.hcl.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.entity.InsuranceCompany;
import com.hcl.training.service.InsuranceCompanyService;


@RestController
public class InsuranceCompanyController {
	
	@Autowired
	InsuranceCompanyService insuranceCompanyService;

	@GetMapping("/companies")
	public ResponseEntity<List<InsuranceCompany>> getCompanies() {
		return new ResponseEntity<List<InsuranceCompany>>(insuranceCompanyService.listInsuranceCompanies(),HttpStatus.OK);

	}
	
	
	@GetMapping("/companies/{companyName}")
	public ResponseEntity<List<InsuranceCompany>> getCompaniesByName(@PathVariable("companyName") String companyName) {
		return new ResponseEntity<List<InsuranceCompany>>(insuranceCompanyService.listInsuranceCompaniesByName(companyName),HttpStatus.OK);

	}
}
