package com.hcl.training.service;

import java.util.List;

import com.hcl.training.entity.Customer;

public interface CustomerService {

	List<Customer> getCustomer();

}
