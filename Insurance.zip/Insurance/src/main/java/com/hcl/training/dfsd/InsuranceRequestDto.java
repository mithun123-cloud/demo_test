package com.hcl.training.dfsd;

public class InsuranceRequestDto {
	
	private Integer insuranceId;
	private Boolean monthlyEMI;
	private Boolean QuaterlyEMI;
	private Boolean yearlyEMI;
	
	
	
	public Integer getInsuranceId() {
		return insuranceId;
	}
	public void setInsuranceId(Integer insuranceId) {
		this.insuranceId = insuranceId;
	}
	public Boolean getMonthlyEMI() {
		return monthlyEMI;
	}
	public void setMonthlyEMI(Boolean monthlyEMI) {
		this.monthlyEMI = monthlyEMI;
	}
	public Boolean getQuaterlyEMI() {
		return QuaterlyEMI;
	}
	public void setQuaterlyEMI(Boolean quaterlyEMI) {
		QuaterlyEMI = quaterlyEMI;
	}
	public Boolean getYearlyEMI() {
		return yearlyEMI;
	}
	public void setYearlyEMI(Boolean yearlyEMI) {
		this.yearlyEMI = yearlyEMI;
	}
	
	

}
