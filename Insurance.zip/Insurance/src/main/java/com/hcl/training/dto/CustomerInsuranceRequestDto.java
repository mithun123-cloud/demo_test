package com.hcl.training.dto;

import java.util.ArrayList;
import java.util.List;

public class CustomerInsuranceRequestDto {
	
	private Long fromAccount;
	
	private Integer customerId;
	
	private List<InsuranceRequestDto> InsuranceRequestDto = new ArrayList<>();

	

	public Long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(Long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public List<InsuranceRequestDto> getInsuranceRequestDto() {
		return InsuranceRequestDto;
	}

	public void setInsuranceRequestDto(List<InsuranceRequestDto> insuranceRequestDto) {
		InsuranceRequestDto = insuranceRequestDto;
	}

	
}
