package com.hcl.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.dto.InsurancesResponseDto;
import com.hcl.training.entity.Insurances;
import com.hcl.training.service.InsurancesService;

@RestController
public class InsurancesController {

	@Autowired
	InsurancesService insurancesService;

	@GetMapping("/insurances")
	public ResponseEntity<List<Insurances>> getCompanies() {
		return new ResponseEntity<List<Insurances>>(insurancesService.listInsurances(),HttpStatus.OK);

	}
	
	
	@GetMapping("/insurances/{insuranceName}")
	public ResponseEntity<List<InsurancesResponseDto>> getCompaniesByName(@PathVariable("insuranceName") String insuranceName) {
		return new ResponseEntity<List<InsurancesResponseDto>>(insurancesService.listInsurancesByName(insuranceName),HttpStatus.OK);

	}
}
