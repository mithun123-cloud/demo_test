package com.hcl.training.service;

import java.util.List;

import com.hcl.training.dto.CustomerInsuranceRequestDto;
import com.hcl.training.dto.CustomerInsuranceResponseDto;

public interface CustomerInsuranceService {

	String optingInsurance(CustomerInsuranceRequestDto customerInsuranceDto);

	List<CustomerInsuranceResponseDto> searchCustomerByUserId(Integer customerId,Integer pageNumber, Integer pageSize);

}
