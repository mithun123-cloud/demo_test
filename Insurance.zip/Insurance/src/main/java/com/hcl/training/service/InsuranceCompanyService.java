package com.hcl.training.service;

import java.util.List;

import com.hcl.training.entity.InsuranceCompany;

public interface InsuranceCompanyService {

	List<InsuranceCompany> listInsuranceCompanies();
	List<InsuranceCompany> listInsuranceCompaniesByName(String comapanyName);

}
