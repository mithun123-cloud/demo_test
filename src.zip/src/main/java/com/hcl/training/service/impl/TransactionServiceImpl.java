package com.hcl.training.service.impl;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hcl.training.entity.Transaction;
import com.hcl.training.repository.TransactionRepository;
import com.hcl.training.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	TransactionRepository transactionRepository;

	@Override
	public List<Transaction> featchRecords(Long accountNo, int pageNumber, int size) throws AccountNotFoundException {
		Pageable pageable = PageRequest.of(pageNumber, size);
		System.out.println(
				"featchRecords in service impl::::" + accountNo + "pageNumber::::" + pageNumber + "size:::" + size);
		List<Transaction> stmt = transactionRepository.featchRecords(accountNo, pageable);
		if (stmt.size() == 0) {
			throw new AccountNotFoundException("Given Account number not available ");
		}
		return stmt;
	}
}
