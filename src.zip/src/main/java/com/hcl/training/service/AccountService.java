package com.hcl.training.service;


import javax.security.auth.login.AccountNotFoundException;
import com.hcl.training.dto.AccountRequestDto;
import com.hcl.training.entity.Transaction;
import com.hcl.training.exception.InsufficientFoundException;

public interface AccountService {


	public Transaction fundTransfer(AccountRequestDto AccountRequestDto) throws  AccountNotFoundException, InsufficientFoundException;


}
