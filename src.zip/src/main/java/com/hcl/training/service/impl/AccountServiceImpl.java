package com.hcl.training.service.impl;

import java.util.Calendar;
import javax.security.auth.login.AccountNotFoundException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.training.dto.AccountRequestDto;
import com.hcl.training.entity.Account;
import com.hcl.training.entity.Transaction;
import com.hcl.training.exception.InsufficientFoundException;
import com.hcl.training.repository.AccountRepository;
import com.hcl.training.repository.TransactionRepository;
import com.hcl.training.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	TransactionRepository transactionRepository;

	@Override
	@Transactional
	public Transaction fundTransfer(AccountRequestDto accountRequestDto)
			throws AccountNotFoundException, InsufficientFoundException {
		System.out.println("from acc::::"+accountRequestDto.getFromAccount()+"ToAccount:::"+accountRequestDto.getToAccount());

		//if (accountRequestDto.getFromAccount() != accountRequestDto.getToAccount() && accountRequestDto.getFromAccount() > 0 && accountRequestDto.getToAccount() > 0) {
		if (accountRequestDto.getFromAccount() > 0 && accountRequestDto.getToAccount() > 0) {

			if (accountRepository.findByAccountNumber(accountRequestDto.getFromAccount()).isPresent()) {

				if (accountRepository.findByAccountNumber(accountRequestDto.getToAccount()).isPresent()) {

					Account fromAmount = accountRepository.findByAccountNumber(accountRequestDto.getFromAccount())
							.get();
					Account toAmount = accountRepository.findByAccountNumber(accountRequestDto.getToAccount())
							.get();

					Transaction transaction = new Transaction();
					
					if (fromAmount.getOpeningBalance() >= accountRequestDto.getAmount()) {
						fromAmount.setOpeningBalance(
								(fromAmount.getOpeningBalance() - accountRequestDto.getAmount()));
						System.out.println("from account executed...........");
						accountRepository.save(fromAmount);
						
						transaction.setFromStatus("debited");

						toAmount.setOpeningBalance(
								(toAmount.getOpeningBalance()) + accountRequestDto.getAmount());

						accountRepository.save(toAmount);
						System.out.println("to account executed...........");
						transaction.setToStatus("credited");

						
						transaction.setAmount(accountRequestDto.getAmount());
						transaction.setFromAccount(accountRequestDto.getFromAccount());
						transaction.setToAccount(accountRequestDto.getToAccount());
						transaction.setDate(Calendar.getInstance().getTime());
						transaction.setRemark(accountRequestDto.getRemarks());
						
						
						transaction = transactionRepository.save(transaction);
						return transaction;

					} else {
						throw new InsufficientFoundException("InSufficiet Amount.");
					}

				} else {
					throw new AccountNotFoundException("To Account Number Not Found!");
				}
			} else {
				throw new AccountNotFoundException("From Account Number Not Found");
			}
		} else {
			throw new AccountNotFoundException("FromAccount  and toAccount number shoud Not same");
		}
	}

}
