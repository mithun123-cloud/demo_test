package com.hcl.training.service;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import com.hcl.training.entity.Transaction;

public interface TransactionService {

	List<Transaction> featchRecords(Long accountNo, int pageNumber,int size) throws AccountNotFoundException;

}
