package com.hcl.training.controller;
import javax.security.auth.login.AccountNotFoundException;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.training.dto.AccountRequestDto;
import com.hcl.training.exception.InsufficientFoundException;
import com.hcl.training.service.AccountService;

@RestController
@RequestMapping("/bank")
public class AccountController {

	private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

	@Autowired
	AccountService accountService;

	@Autowired
	Environment environment;
	
	
	
	@PostMapping("/fundTransfer")
	public ResponseEntity<String> fundTransfer(@Valid @RequestBody AccountRequestDto accountRequestDto)
			throws AccountNotFoundException, InsufficientFoundException {
		logger.info("fundTransafer::" + accountRequestDto);
		System.out.println("fundTransafer::1--------" + accountRequestDto);
		accountService.fundTransfer(accountRequestDto);
		return new ResponseEntity<String>("Fund Transferred successfully", HttpStatus.OK);
	}
	
	
	/*
	 * @PostMapping("/fundTransfer") public String fundTransfer(@Valid @RequestBody
	 * AccountRequestDto accountRequestDto) throws AccountNotFoundException,
	 * InsufficientFoundException {
	 * logger.info("fundTransafer::"+accountRequestDto);
	 * System.out.println("fundTransafer::1--------"+accountRequestDto);
	 * accountService.fundTransfer(accountRequestDto); return
	 * "Fund Transferred successfully"; }
	 */
	
	
	@GetMapping("/port")
	public String getInfo() {
		String port = environment.getProperty("local.server.port");
		return "from server" + port;
	}
	 
	
	/*
	 * @ResponseStatus(HttpStatus.BAD_REQUEST)
	 * 
	 * @ExceptionHandler(MethodArgumentNotValidException.class) public Map<String,
	 * String> h(MethodArgumentNotValidException ex) { Map<String, String> errors =
	 * new HashMap<>(); ex.getBindingResult().getFieldErrors() .forEach(error ->
	 * errors.put(error.getField(), error.getDefaultMessage())); return errors; }
	 */
	
}
