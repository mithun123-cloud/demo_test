package com.hcl.training.controller;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.entity.Transaction;
import com.hcl.training.service.TransactionService;


@RestController
public class TransactionController {

	private static final Logger logger = LoggerFactory.getLogger(TransactionController.class);

	@Autowired
	TransactionService transactionService;

	@GetMapping("/history/{accountNo}")
	public ResponseEntity<List<Transaction>> featchRecords(@PathVariable("accountNo") Long accountNo,
			@RequestParam int pageNumber, @RequestParam int size) throws AccountNotFoundException {
		logger.info("featchRecords:::"+accountNo);
		List<Transaction> transactionList = transactionService.featchRecords(accountNo, pageNumber, size);
		return new ResponseEntity<List<Transaction>>(transactionList, new HttpHeaders(), HttpStatus.OK);
	}
}
