package com.hcl.training.exception;

public class MiniumAmountDeposit {

}
