package com.hcl.training.exception;

public class DailyWithdrawLimitExceededExecption {

}
