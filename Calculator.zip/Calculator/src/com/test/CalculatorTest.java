package com.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;

import com.java.Calculator;

@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
public class CalculatorTest {
	
	Calculator calculator;
	
	@BeforeAll
	public void setUp() {
		calculator = new Calculator();
	}
	
	/*
	 * @Nested class nestedClass() { public void entry_method() {} }
	 */
	
	@Test
	@DisplayName("Addition function")
	@Order(3)
	public void addTest() {
		int result = calculator.add(4, 5);
		assertEquals(9, result);
		System.out.println("value:"+this);
	}
	
	@Test
	@DisplayName("Substraction function")
	@Order(2)
	public void subTest() {
		int result = calculator.sub(10, 5);
		assertEquals(5, result);
		System.out.println("value:"+this);
	}
	
	
	@Test
	@DisplayName("Multiplication function")
	@Order(1)
	public void mulTest() {
		int result = calculator.mul(4, 5);
		assertEquals(20, result);
		System.out.println("value:"+this);
	}
	
	@Test
	@DisplayName("Div function")
	@Order(4)
	public void divTest() {
		int result = calculator.div(40, 5);
		assertEquals(8, result);
		System.out.println("value:"+this);
	}

}
