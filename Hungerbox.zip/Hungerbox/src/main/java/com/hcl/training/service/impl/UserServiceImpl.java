package com.hcl.training.service.impl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.training.dto.UserDto;
import com.hcl.training.entity.User;
import com.hcl.training.exception.UserNotFoundException;
import com.hcl.training.repository.UserRepository;
import com.hcl.training.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	@Override
	public String addUser(UserDto userDto) {
		System.out.println("userDto:::" + userDto);
		User newUser = new User();
		BeanUtils.copyProperties(userDto, newUser);
		System.out.println("newUser:::" + newUser);
		User savedUser = userRepository.save(newUser);
		Optional<User> userUpdated = userRepository.findById(savedUser.getUserId());
		String message = null;
		if (userUpdated.isPresent()) {
			message = "User Saved Successfully.";
		} else {
			message = "User Not Saved .";
		}
		return message;

	}

	@Override
	public UserDto getUser(Integer userId) throws UserNotFoundException {
		if (userRepository.findById(userId).isPresent()) {
			UserDto userDto = new UserDto();
			User user = userRepository.findById(userId).get();
			BeanUtils.copyProperties(user, userDto);

			return userDto;

		} else {
			throw new UserNotFoundException("Id Not Found");
		}
	}

}
