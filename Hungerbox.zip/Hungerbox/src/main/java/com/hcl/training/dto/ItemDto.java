package com.hcl.training.dto;

public class ItemDto {

}
