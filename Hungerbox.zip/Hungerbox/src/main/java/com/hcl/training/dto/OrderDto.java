package com.hcl.training.dto;

public class OrderDto {

}
