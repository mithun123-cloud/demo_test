package com.hcl.training.service;


import java.util.List;

import com.hcl.training.dto.FoodItemRequestDto;
import com.hcl.training.dto.FoodItemResponseDto;
import com.hcl.training.exception.FoodItemNotFoundException;

public interface FoodItemService {


	String createItem(FoodItemRequestDto foodItemRequestDto) throws FoodItemNotFoundException;

	List<FoodItemResponseDto> findByitemName(String itemName);
	
	FoodItemResponseDto getItem(Integer itemId);

}
