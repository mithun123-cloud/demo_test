package com.hcl.training.service;

import com.hcl.training.dto.UserDto;
import com.hcl.training.exception.UserNotFoundException;

public interface UserService {

	String addUser(UserDto userDto);

	UserDto getUser(Integer userId) throws UserNotFoundException;

}
