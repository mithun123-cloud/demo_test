package com.hcl.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.dto.UserOrderRequestDto;
import com.hcl.training.dto.UserOrderResponseDto;
import com.hcl.training.entity.UserOrder;
import com.hcl.training.service.UserOrderService;

@RestController
public class UserOrderController {
	
	@Autowired
	UserOrderService userOrderService;
	
	
	@GetMapping("/getUserOrderByuserId/{userId}")
	public ResponseEntity<List<UserOrderResponseDto>> getUserOrderByuserId(@PathVariable("userId") Integer userId){
		System.out.println("getUserOrderByuserId..............");
		return new ResponseEntity<List<UserOrderResponseDto>>(userOrderService.getUserOrderByuserId(userId),HttpStatus.OK);
	}
	
	
	@PostMapping("/userOrder/{userId}")
	public ResponseEntity<String> addUserOrder(@PathVariable("userId") Integer userId, @RequestBody UserOrderRequestDto userOrderRequestDto)  {
		
		System.out.println("addUser in controller ...userOrderRequestDto:::"+userOrderRequestDto);
		
		return new ResponseEntity<String>(userOrderService.addUserOrder(userOrderRequestDto, userId),HttpStatus.CREATED);
	}
	
	@GetMapping("/getUserOrder/{orderId}")
	public ResponseEntity<UserOrder> getUserOrder(@PathVariable("orderId") Integer orderId){
		System.out.println("getUserOrder..............");
		return new ResponseEntity<UserOrder>(userOrderService.getUserOrder(orderId),HttpStatus.OK);
	}
	
	
	@GetMapping("/getUserOrders")
	public ResponseEntity<List<UserOrder>> getUserOrders(){
		System.out.println("getUserOrders.....all.........");
		return new ResponseEntity<List<UserOrder>>(userOrderService.getUserOrders(),HttpStatus.OK);
	}
	
}
