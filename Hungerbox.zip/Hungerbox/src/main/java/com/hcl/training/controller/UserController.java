package com.hcl.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.dto.UserDto;
import com.hcl.training.exception.UserNotFoundException;
import com.hcl.training.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("/adduser/{userId}")
	public ResponseEntity<String> addUser(@RequestBody UserDto userDto) {
		System.out.println("addUser.................");
		String message = userService.addUser(userDto);
		return new ResponseEntity<String>(message,HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/user/{userId}")
	public ResponseEntity<UserDto> getUser(@PathVariable("userId") Integer userId) throws UserNotFoundException {
		System.out.println("addUser.................");
		return new ResponseEntity<UserDto>(userService.getUser(userId),HttpStatus.OK);
	}

}
