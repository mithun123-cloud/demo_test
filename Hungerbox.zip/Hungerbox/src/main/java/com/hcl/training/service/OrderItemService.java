package com.hcl.training.service;

import java.util.List;
import java.util.Optional;

import com.hcl.training.dto.OrderItemRequestDto;
import com.hcl.training.dto.OrderItemResponseDto;
import com.hcl.training.entity.OrderItem;

public interface OrderItemService {
	
	String addOrderItem(OrderItem orderItem);

	List<OrderItem> searchOrderItemByUserId(Integer userId);

	List<OrderItem> findByUserId(Integer userId);

}
