package com.hcl.training.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.training.dto.FoodItemResponseDto;
import com.hcl.training.entity.FoodItem;

public interface FoodItemRepository extends JpaRepository<FoodItem, Integer>{

	List<FoodItemResponseDto> findByVenderVenderId(Integer venderId);

	//List<FoodItemResponseDto> findByUserUserId(Integer userId);
	
	//List<Item> findByVenderNameContainsOrItemNameContains(String venderName, String itemName);
	
	List<FoodItem> findByItemNameContains(String itemName);

}
