package com.hcl.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.dto.FoodItemRequestDto;
import com.hcl.training.dto.FoodItemResponseDto;
import com.hcl.training.exception.FoodItemNotFoundException;
import com.hcl.training.service.FoodItemService;


@RestController
public class FoodItemController {
	
	@Autowired
	FoodItemService foodItemService;
	
	
	@GetMapping("/foodItem")
	public ResponseEntity<List<FoodItemResponseDto>> findByitemName(@RequestParam("itemName") String itemName)throws FoodItemNotFoundException {
		System.out.println("findByitemName........in controller.......");
		List<FoodItemResponseDto> itemLists = foodItemService.findByitemName(itemName);
		return new ResponseEntity<List<FoodItemResponseDto>> (itemLists, HttpStatus.OK);
	}
	
	
	@PostMapping(value = "/foodItem")
	public ResponseEntity<String> createItem(@RequestBody FoodItemRequestDto foodItemRequestDto) throws FoodItemNotFoundException {
		System.out.println("createItem.............");
		String items = foodItemService.createItem(foodItemRequestDto);
		return new ResponseEntity<String>(items, HttpStatus.ACCEPTED);
	}
	
	
	
	

}
