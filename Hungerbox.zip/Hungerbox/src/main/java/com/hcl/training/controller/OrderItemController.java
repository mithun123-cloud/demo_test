package com.hcl.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.entity.OrderItem;
import com.hcl.training.service.OrderItemService;

@RestController
public class OrderItemController {

	@Autowired
	OrderItemService orderItemService;

	@PostMapping("/addOrderItem")
	public ResponseEntity<String> addOrderItem(@RequestBody OrderItem orderItem) {

		System.out.println("addOrderItem in controller ...orderItem:::" + orderItem);

		return new ResponseEntity<String>(orderItemService.addOrderItem(orderItem), HttpStatus.CREATED);
	}
	
	
	
	
	@GetMapping("/searchOrderItemByUserId")
	public List<OrderItem> searchOrderItemByUserId(@RequestParam Integer userId) {
		return orderItemService.searchOrderItemByUserId(userId);

	}
	
	@GetMapping("/searchOrderByUserId")
	public List<OrderItem> getOrdersById(@RequestParam Integer userId) {
		return orderItemService.findByUserId(userId);

	}
}
