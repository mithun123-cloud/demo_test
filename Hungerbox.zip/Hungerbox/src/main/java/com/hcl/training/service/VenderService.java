package com.hcl.training.service;

import com.hcl.training.dto.VenderRequestDto;
import com.hcl.training.dto.VenderResponseDto;
import com.hcl.training.exception.VenderNotFoundException;

public interface VenderService {

	String addVender(VenderRequestDto VenderRequestDto);
	
	VenderResponseDto getVender(Integer VenderId) throws VenderNotFoundException;
	
	VenderResponseDto getVenderByName(String venderName) throws VenderNotFoundException;
}
