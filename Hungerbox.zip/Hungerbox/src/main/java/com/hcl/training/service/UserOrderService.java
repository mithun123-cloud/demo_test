package com.hcl.training.service;

import java.util.List;

import com.hcl.training.dto.UserOrderRequestDto;
import com.hcl.training.dto.UserOrderResponseDto;
import com.hcl.training.entity.UserOrder;

public interface UserOrderService {

	String addUserOrder(UserOrderRequestDto userOrderRequestDto, Integer userId );

	//List<UserOrderResponseDto> getAllUserOrder();
	
	UserOrder getUserOrder(Integer userOrderId);
	
	List<UserOrder> getUserOrders();

	List<UserOrderResponseDto> getUserOrderByuserId(Integer userId);

}
