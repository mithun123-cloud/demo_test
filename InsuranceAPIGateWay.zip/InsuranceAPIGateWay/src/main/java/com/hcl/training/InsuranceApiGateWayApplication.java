package com.hcl.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

@SpringBootApplication
@EnableZuulProxy
@EnableEurekaClient
public class InsuranceApiGateWayApplication {

	public static void main(String[] args) {
		System.out.println("in API gateway..........");
		SpringApplication.run(InsuranceApiGateWayApplication.class, args);
	}

}
